package geasipan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class geasipanwrite 
{
		private Connection conn; 
		private ResultSet rs;

		public geasipanwrite() 
		{
			try {
				String url = "jdbc:mysql://localhost:3306/1pmmidia";
			    String id = "root";
			    String pwd = "7891";
			    
				Class.forName("com.mysql.jdbc.Driver");
				conn = DriverManager.getConnection(url, id, pwd);
				
			} catch (Exception e) 
			{
				e.printStackTrace(); 
			}
		}

		
		public String getDate() 
		{ 
			String SQL = "SELECT NOW()";
			try {
				PreparedStatement pstmt = conn.prepareStatement(SQL);
				rs = pstmt.executeQuery();
				if(rs.next()) {
					return rs.getString(1);
				}
			} catch (Exception e)
			{
				e.printStackTrace();
			}
			return ""; 
		}

		
			public int getNext()
			{ 
				String SQL = "SELECT number FROM 1pmmidia.boardwrite ORDER BY number DESC";
				try {
					PreparedStatement pstmt = conn.prepareStatement(SQL);
					rs = pstmt.executeQuery();
					
					if(rs.next()) 
					{
						return rs.getInt(1) + 1;
					}
					return 1;
				} catch (Exception e) 
				{
					e.printStackTrace();
				}
				return -1; 
			}

			
			public int write(String title, String userID, String userTel, String content) 
			{ 
				String SQL = "INSERT INTO 1pmmidia.boardwrite VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
				try {
					PreparedStatement pstmt = conn.prepareStatement(SQL);
					pstmt.setInt(1, getNext());
					pstmt.setString(2, title);
					pstmt.setString(3, userID);
					pstmt.setString(4, userTel);
					pstmt.setString(5, getDate());
					pstmt.setString(6, content);
					pstmt.setInt(7, 0);
					pstmt.setInt(8, 0);
					pstmt.setInt(9, 1);
					
					return pstmt.executeUpdate();
				} catch (Exception e) 
				{
					e.printStackTrace();
				}
				return -1; //데이터베이스 오류
			}
		
			
			public ArrayList<geasipan> getList(int pageNumber){ 
				String SQL = "SELECT * FROM 1pmmidia.boardwrite WHERE number < ? AND deletes = 1 ORDER BY number DESC LIMIT 10";
				ArrayList<geasipan> list = new ArrayList<geasipan>();
				try {
					PreparedStatement pstmt = conn.prepareStatement(SQL);
					pstmt.setInt(1, getNext() - (pageNumber -1) * 10);
					rs = pstmt.executeQuery();
					
					while (rs.next()) {
						geasipan geasipan = new geasipan();
						
						geasipan.setnumber(rs.getInt(1));
						geasipan.settitle(rs.getString(2));
						geasipan.setuserID(rs.getString(3));
						geasipan.setuserTel(rs.getString(4));
						geasipan.setdate(rs.getString(5));
						geasipan.setcontent(rs.getString(6));
						geasipan.setgood(rs.getInt(7));
						geasipan.setnotgood(rs.getInt(8));
						geasipan.setdelete(rs.getInt(9));

						list.add(geasipan);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				return list; 
			}
			
			
			public boolean nextPage (int pageNumber) {
				String SQL = "SELECT * FROM 1pmmidia.boardwrite WHERE number < ? and deletes = 1";
				try {
					PreparedStatement pstmt = conn.prepareStatement(SQL);
					pstmt.setInt(1, getNext() - (pageNumber -1) * 10);
					rs = pstmt.executeQuery();
					
					if (rs.next()) {
						return true;
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return false; 		
			}
			
			
			public geasipan getgeasipan(int number) {
				String SQL = "SELECT * FROM 1pmmidia.boardwrite WHERE number = ?";
				try {
					PreparedStatement pstmt = conn.prepareStatement(SQL);
					pstmt.setInt(1, number);
					rs = pstmt.executeQuery();
					if (rs.next()) {
						geasipan geasipan = new geasipan();
						geasipan.setnumber(rs.getInt(1));
						geasipan.settitle(rs.getString(2));
						geasipan.setuserID(rs.getString(3));
						geasipan.setuserTel(rs.getString(4));
						geasipan.setdate(rs.getString(5));
						geasipan.setcontent(rs.getString(6));
						geasipan.setgood(rs.getInt(7));
						geasipan.setnotgood(rs.getInt(8));
						geasipan.setdelete(rs.getInt(9));

						return geasipan;
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return null;
			}
			
			
			public int update(int number, String title, String content) {
				String SQL = "UPDATE 1pmmidia.boardwrite SET title = ?, content = ? WHERE number = ?";

				try {
					PreparedStatement pstmt = conn.prepareStatement(SQL);
					pstmt.setString(1, title);
					pstmt.setString(2, content);
					pstmt.setInt(3, number);
					return pstmt.executeUpdate();
				} catch (Exception e) {
					e.printStackTrace();
				}
				return -1; // 데이터베이스 오류
			}
			
			
			public int delete(int number) {
				String SQL = "delete from 1pmmidia.boardwrite WHERE deletes = 1 and number = ?";

				try {
					PreparedStatement pstmt = conn.prepareStatement(SQL);   
					pstmt.setInt(1, number);
					return pstmt.executeUpdate();
				} catch (Exception e) {
				e.printStackTrace();
				}
				return -1; // 데이터베이스 오류
			}

			
			public int good(int number) {
				String SQL = "update 1pmmidia.boardwrite SET good = good + 1 where number = ?";

				try {
					PreparedStatement pstmt = conn.prepareStatement(SQL);   
					pstmt.setInt(1, number);
					return pstmt.executeUpdate();
				} catch (Exception e) {
				e.printStackTrace();
				}
				return -1; 
			}
			
			
			public int notgood(int number) {
				String SQL = "update 1pmmidia.boardwrite SET notgood = notgood + 1 where number = ?";

				try {
					PreparedStatement pstmt = conn.prepareStatement(SQL);   
					pstmt.setInt(1, number);
					return pstmt.executeUpdate();
				} catch (Exception e) {
				e.printStackTrace();
				}
				return -1; 
			}
		}
