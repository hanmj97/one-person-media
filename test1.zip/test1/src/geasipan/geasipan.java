package geasipan;

public class geasipan {
	private int number;
	private String title;
	private String userID;
	private String userTel;
	private String date;
	private String content;
	private int good;
	private int notgood;
	private int delete;
	public int getnumber() {
		return number;
	}
	public void setnumber(int number) {
		this.number = number;
	}
	public String gettitle() {
		return title;
	}
	public void settitle(String title) {
		this.title = title;
	}
	public String getuserID() {
		return userID;
	}
	public void setuserID(String userID) {
		this.userID = userID;
	}
	public String getuserTel() {
		return userTel;
	}
	public void setuserTel(String userTel) {
		this.userTel = userTel;
	}
	public String getdate() {
		return date;
	}
	public void setdate(String date) {
		this.date = date;
	}
	public String getcontent() {
		return content;
	}
	public void setcontent(String content) {
		this.content = content;
	}
	public int getgood() {
		return good;
	}
	public void setgood(int good) {
		this.good = good;
	}
	public int getnotgood() {
		return notgood;
	}
	public void setnotgood(int notgood) {
		this.notgood = notgood;
	}
	public int getdelete() {
		return delete;
	}
	public void setdelete(int delete) {
		this.delete = delete;
	}

}