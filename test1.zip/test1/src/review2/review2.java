package review2;

public class review2 {

	private int reviewnumber;
	private String userID;
	private String content;
	private String date;
	private int number;
	public int getreviewnumber() {
		return reviewnumber;
	}
	public void setreviewnumber(int reviewnumber) {
		this.reviewnumber = reviewnumber;
	}
	public String getuserID() {
		return userID;
	}
	public void setuserID(String userID) {
		this.userID = userID;
	}
	public String getcontent() {
		return content;
	}
	public void setcontent(String content) {
		this.content = content;
	}
	public String getdate() {
		return date;
	}
	public void setdate(String date) {
		this.date = date;
	}
	public int getnumber() {
		return number;
	}
	public void setnumber(int number) {
		this.number = number;
	}
}
